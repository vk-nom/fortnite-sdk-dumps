// SolarisGeneratedEnum Diagnostics_diagnostics_log_level.diagnostics_log_level
enum class diagnostics_log_level : uint8 {
	debug,
	Verbose,
	Normal,
	Warning,
	Error,
	Fatal,
};

