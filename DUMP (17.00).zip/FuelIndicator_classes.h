// BlueprintGeneratedClass FuelIndicator.FuelIndicator_C
// Size: 0x8a8 (Inherited: 0x898)
struct AFuelIndicator_C : ABuildingGameplayActor {
	struct UAthenaSpecialActorComponent* AthenaSpecialActor; // 0x898(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x8a0(0x08)
};

