// BlueprintGeneratedClass GA_Athena_Banana.GA_Athena_Banana_C
// Size: 0xc18 (Inherited: 0xc18)
struct UGA_Athena_Banana_C : UGA_Athena_ForagedItemVersion_Consume_Parent_C {
};

