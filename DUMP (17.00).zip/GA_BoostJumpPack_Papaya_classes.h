// BlueprintGeneratedClass GA_BoostJumpPack_Papaya.GA_BoostJumpPack_Papaya_C
// Size: 0xc38 (Inherited: 0xc38)
struct UGA_BoostJumpPack_Papaya_C : UGA_BoostJumpPack_C {
};

