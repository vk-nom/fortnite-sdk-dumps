// BlueprintGeneratedClass GCN_Athena_ReactorGrade_Trail.GCN_Athena_ReactorGrade_Trail_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_Athena_ReactorGrade_Trail_C : UFortGameplayCueNotify_Burst {
};

