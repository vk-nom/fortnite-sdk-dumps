// UserDefinedEnum Enum_NPC_TargetSlots.Enum_NPC_TargetSlots
enum class Enum_NPC_TargetSlots : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	Enum_NPC_MAX,
};

