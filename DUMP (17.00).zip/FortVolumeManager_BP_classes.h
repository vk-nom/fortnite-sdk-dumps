// BlueprintGeneratedClass FortVolumeManager_BP.FortVolumeManager_BP_C
// Size: 0x570 (Inherited: 0x570)
struct AFortVolumeManager_BP_C : AFortVolumeManager {
};

