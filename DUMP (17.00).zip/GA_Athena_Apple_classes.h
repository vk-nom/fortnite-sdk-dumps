// BlueprintGeneratedClass GA_Athena_Apple.GA_Athena_Apple_C
// Size: 0xc18 (Inherited: 0xc18)
struct UGA_Athena_Apple_C : UGA_Athena_ForagedItemVersion_Consume_Parent_C {
};

