// BlueprintGeneratedClass GCNS_GM_OnPreviewEmoji.GCNS_GM_OnPreviewEmoji_C
// Size: 0x1c0 (Inherited: 0x1c0)
struct UGCNS_GM_OnPreviewEmoji_C : UGameplayCueNotify_OnPreviewEmoji {
};

