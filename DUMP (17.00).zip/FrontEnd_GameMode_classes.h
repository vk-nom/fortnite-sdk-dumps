// BlueprintGeneratedClass FrontEnd_GameMode.FrontEnd_GameMode_C
// Size: 0x6d8 (Inherited: 0x6d0)
struct AFrontEnd_GameMode_C : AFortGameModeFrontEnd {
	struct USceneComponent* DefaultSceneRoot; // 0x6d0(0x08)
};

