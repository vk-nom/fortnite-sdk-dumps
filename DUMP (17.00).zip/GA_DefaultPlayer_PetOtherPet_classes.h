// BlueprintGeneratedClass GA_DefaultPlayer_PetOtherPet.GA_DefaultPlayer_PetOtherPet_C
// Size: 0xa78 (Inherited: 0xa70)
struct UGA_DefaultPlayer_PetOtherPet_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)

	void OnCancelled_FB7AFE5D4FF547CAEB1ECA8264EE1330(); // Function GA_DefaultPlayer_PetOtherPet.GA_DefaultPlayer_PetOtherPet_C.OnCancelled_FB7AFE5D4FF547CAEB1ECA8264EE1330 // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnInterrupted_FB7AFE5D4FF547CAEB1ECA8264EE1330(); // Function GA_DefaultPlayer_PetOtherPet.GA_DefaultPlayer_PetOtherPet_C.OnInterrupted_FB7AFE5D4FF547CAEB1ECA8264EE1330 // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnBlendOut_FB7AFE5D4FF547CAEB1ECA8264EE1330(); // Function GA_DefaultPlayer_PetOtherPet.GA_DefaultPlayer_PetOtherPet_C.OnBlendOut_FB7AFE5D4FF547CAEB1ECA8264EE1330 // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnCompleted_FB7AFE5D4FF547CAEB1ECA8264EE1330(); // Function GA_DefaultPlayer_PetOtherPet.GA_DefaultPlayer_PetOtherPet_C.OnCompleted_FB7AFE5D4FF547CAEB1ECA8264EE1330 // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void K2_ActivateAbility(); // Function GA_DefaultPlayer_PetOtherPet.GA_DefaultPlayer_PetOtherPet_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_DefaultPlayer_PetOtherPet(int32_t EntryPoint); // Function GA_DefaultPlayer_PetOtherPet.GA_DefaultPlayer_PetOtherPet_C.ExecuteUbergraph_GA_DefaultPlayer_PetOtherPet // (Final|UbergraphFunction) // @ game+0xda7c34
};

