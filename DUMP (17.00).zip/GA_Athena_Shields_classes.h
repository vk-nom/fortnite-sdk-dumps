// BlueprintGeneratedClass GA_Athena_Shields.GA_Athena_Shields_C
// Size: 0xc09 (Inherited: 0xc09)
struct UGA_Athena_Shields_C : UGA_Athena_MedConsumable_Parent_C {
};

