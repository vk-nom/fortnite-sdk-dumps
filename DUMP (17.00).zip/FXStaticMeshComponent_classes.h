// BlueprintGeneratedClass FXStaticMeshComponent.FXStaticMeshComponent_C
// Size: 0x500 (Inherited: 0x500)
struct UFXStaticMeshComponent_C : UFortFXStaticMeshComponent {

	void ApplyAwakenEffect(); // Function FXStaticMeshComponent.FXStaticMeshComponent_C.ApplyAwakenEffect // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void ApplyEffect(struct UMaterialInterface* Source Material, float FadeInTime, float Duration, float FadeOutTimer); // Function FXStaticMeshComponent.FXStaticMeshComponent_C.ApplyEffect // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void ApplyBuildingHitEffect(); // Function FXStaticMeshComponent.FXStaticMeshComponent_C.ApplyBuildingHitEffect // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
};

