// BlueprintGeneratedClass GE_Athena_DBNO_Start.GE_Athena_DBNO_Start_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_DBNO_Start_C : UGE_Map_Fortitude_To_Health_C {
};

