// SolarisGeneratedEnum Entity_Client_local_controller_slot.local_controller_slot
enum class local_controller_slot : uint8 {
	Disabled,
	Controller0,
	Controller1,
	Controller2,
	Controller3,
	Controller4,
	Controller5,
	Controller6,
	Controller7,
};

