// BlueprintGeneratedClass DefaultBuildingTool.DefaultBuildingTool_C
// Size: 0xf58 (Inherited: 0xf58)
struct ADefaultBuildingTool_C : AFortWeap_BuildingTool {
};

