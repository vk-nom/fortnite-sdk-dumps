// UserDefinedStruct FortUITheme.FortUITheme
// Size: 0x60 (Inherited: 0x00)
struct FFortUITheme {
	struct FLinearColor Light_2_BAF9E4AF40C0A5C1B86A439B79B3A1E4; // 0x00(0x10)
	struct FLinearColor Faded_5_2FCC8A1C4BA623597B91E882E0A95F26; // 0x10(0x10)
	struct FLinearColor Active_8_10AE283B44A455DE7AF248B79132A69C; // 0x20(0x10)
	struct FLinearColor Normal_11_F26C9BAB4EC26A2F2B63A6A5F67AE748; // 0x30(0x10)
	struct FLinearColor Dark_14_B49822CC48FC28E72DFACCA1F36B2C18; // 0x40(0x10)
	struct FLinearColor Ultra_17_D9B7B92B475B19E3C7733C85FA62631C; // 0x50(0x10)
};

