// BlueprintGeneratedClass GE_Athena_HidingProp_ApplyTeleportGA.GE_Athena_HidingProp_ApplyTeleportGA_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_HidingProp_ApplyTeleportGA_C : UGameplayEffect {
};

