// BlueprintGeneratedClass GA_Athena_Meat.GA_Athena_Meat_C
// Size: 0xc09 (Inherited: 0xc09)
struct UGA_Athena_Meat_C : UGA_Athena_MedConsumable_Parent_C {
};

