// BlueprintGeneratedClass GA_Ranged_PastaRipper_Damage.GA_Ranged_PastaRipper_Damage_C
// Size: 0xab1 (Inherited: 0xaa8)
struct UGA_Ranged_PastaRipper_Damage_C : UFortGameplayAbility_RangedWeapon {
	struct FGameplayTag GT_EventWeaponFire; // 0xaa8(0x08)
	bool ManualFireEvent; // 0xab0(0x01)

	void GetEventData(struct FGameplayTag EventTag, struct FGameplayEventData GameplayEventData); // Function GA_Ranged_PastaRipper_Damage.GA_Ranged_PastaRipper_Damage_C.GetEventData // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void K2_CommitExecute(); // Function GA_Ranged_PastaRipper_Damage.GA_Ranged_PastaRipper_Damage_C.K2_CommitExecute // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
};

