// SolarisGeneratedClass Entity_Player_player_component.player_component
// Size: 0xe0 (Inherited: 0xe0)
struct Uplayer_component : UEntityActorPlayerComponent {

	void $InitCDO(); // Function Entity_Player_player_component.player_component.$InitCDO // (None) // @ game+0xda7c34
};

