// UserDefinedStruct FluidForceSocketInfo.FluidForceSocketInfo
// Size: 0x50 (Inherited: 0x00)
struct FFluidForceSocketInfo {
	struct TMap<struct FName, struct FName> SocketsandEndpoints_6_B3EDD8FC43A7C681151F46BE0AA158C5; // 0x00(0x50)
};

