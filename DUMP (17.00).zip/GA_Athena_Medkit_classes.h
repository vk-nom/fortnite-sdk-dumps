// BlueprintGeneratedClass GA_Athena_Medkit.GA_Athena_Medkit_C
// Size: 0xc09 (Inherited: 0xc09)
struct UGA_Athena_Medkit_C : UGA_Athena_MedConsumable_Parent_C {
};

