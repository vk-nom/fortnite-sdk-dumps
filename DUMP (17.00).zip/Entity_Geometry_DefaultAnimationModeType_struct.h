// SolarisGeneratedEnum Entity_Geometry_DefaultAnimationModeType.DefaultAnimationModeType
enum class DefaultAnimationModeType : uint8 {
	UseAnimationBlueprint,
	UseAnimationAsset,
	UseCustomMode,
};

