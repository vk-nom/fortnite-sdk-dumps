// UserDefinedEnum FluidBoundary.FluidBoundary
enum class FluidBoundary : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	FluidBoundary_MAX,
};

