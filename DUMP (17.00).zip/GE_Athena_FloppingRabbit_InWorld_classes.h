// BlueprintGeneratedClass GE_Athena_FloppingRabbit_InWorld.GE_Athena_FloppingRabbit_InWorld_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_FloppingRabbit_InWorld_C : UGameplayEffect {
};

