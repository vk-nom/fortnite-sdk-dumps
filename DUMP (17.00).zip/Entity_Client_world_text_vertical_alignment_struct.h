// SolarisGeneratedEnum Entity_Client_world_text_vertical_alignment.world_text_vertical_alignment
enum class world_text_vertical_alignment : uint8 {
	TextTop,
	TextCenter,
	TextBottom,
	QuadTop,
};

