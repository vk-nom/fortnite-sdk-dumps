// BlueprintGeneratedClass GCNL_Creative_Powerup_HealthNegative.GCNL_Creative_Powerup_HealthNegative_C
// Size: 0x7d0 (Inherited: 0x7d0)
struct AGCNL_Creative_Powerup_HealthNegative_C : AFortGameplayCueNotify_Loop {
};

