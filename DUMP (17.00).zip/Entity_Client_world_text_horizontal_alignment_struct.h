// SolarisGeneratedEnum Entity_Client_world_text_horizontal_alignment.world_text_horizontal_alignment
enum class world_text_horizontal_alignment : uint8 {
	Left,
	Center,
	Right,
};

