// BlueprintGeneratedClass GA_Athena_Corn.GA_Athena_Corn_C
// Size: 0xc18 (Inherited: 0xc18)
struct UGA_Athena_Corn_C : UGA_Athena_ForagedItemVersion_Consume_Parent_C {
};

