// BlueprintGeneratedClass FrontendCamera_Main.FrontendCamera_Main_C
// Size: 0x7f0 (Inherited: 0x7e0)
struct AFrontendCamera_Main_C : AFortCameraBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x7e0(0x08)
	struct UCameraComponent* LoginCamera_1; // 0x7e8(0x08)

	void OnActivated(struct AFortPlayerController* PlayerController); // Function FrontendCamera_Main.FrontendCamera_Main_C.OnActivated // (Event|Public|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_FrontendCamera_Main(int32_t EntryPoint); // Function FrontendCamera_Main.FrontendCamera_Main_C.ExecuteUbergraph_FrontendCamera_Main // (Final|UbergraphFunction|HasDefaults) // @ game+0xda7c34
};

