// BlueprintGeneratedClass GA_AthenaEnterVehicle.GA_AthenaEnterVehicle_C
// Size: 0xa78 (Inherited: 0xa70)
struct UGA_AthenaEnterVehicle_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)

	void K2_ActivateAbility(); // Function GA_AthenaEnterVehicle.GA_AthenaEnterVehicle_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_AthenaEnterVehicle(int32_t EntryPoint); // Function GA_AthenaEnterVehicle.GA_AthenaEnterVehicle_C.ExecuteUbergraph_GA_AthenaEnterVehicle // (Final|UbergraphFunction|HasDefaults) // @ game+0xda7c34
};

