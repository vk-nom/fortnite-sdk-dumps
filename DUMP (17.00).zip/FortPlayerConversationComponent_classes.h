// BlueprintGeneratedClass FortPlayerConversationComponent.FortPlayerConversationComponent_C
// Size: 0x340 (Inherited: 0x340)
struct UFortPlayerConversationComponent_C : UFortPlayerConversationComponent {
};

