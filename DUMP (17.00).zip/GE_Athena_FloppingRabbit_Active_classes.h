// BlueprintGeneratedClass GE_Athena_FloppingRabbit_Active.GE_Athena_FloppingRabbit_Active_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_FloppingRabbit_Active_C : UGameplayEffect {
};

