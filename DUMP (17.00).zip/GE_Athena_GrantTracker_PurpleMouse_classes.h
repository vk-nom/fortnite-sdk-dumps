// BlueprintGeneratedClass GE_Athena_GrantTracker_PurpleMouse.GE_Athena_GrantTracker_PurpleMouse_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_GrantTracker_PurpleMouse_C : UGameplayEffect {
};

