// BlueprintGeneratedClass FloorJumpPad_Immunity_Applied.FloorJumpPad_Immunity_Applied_C
// Size: 0x800 (Inherited: 0x800)
struct UFloorJumpPad_Immunity_Applied_C : UGameplayEffect {
};

