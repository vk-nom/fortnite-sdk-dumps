// UserDefinedEnum Enum_NPC_AlertLevel.Enum_NPC_AlertLevel
enum class Enum_NPC_AlertLevel : uint8 {
	NewEnumerator4,
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	Enum_NPC_MAX,
};

