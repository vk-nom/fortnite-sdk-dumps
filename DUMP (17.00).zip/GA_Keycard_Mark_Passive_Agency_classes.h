// BlueprintGeneratedClass GA_Keycard_Mark_Passive_Agency.GA_Keycard_Mark_Passive_Agency_C
// Size: 0xaa4 (Inherited: 0xaa4)
struct UGA_Keycard_Mark_Passive_Agency_C : UGA_Keycard_Mark_Passive_Parent_C {
};

