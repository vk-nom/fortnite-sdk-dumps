// BlueprintGeneratedClass GA_Athena_FlopperSmall.GA_Athena_FlopperSmall_C
// Size: 0xc18 (Inherited: 0xc09)
struct UGA_Athena_FlopperSmall_C : UGA_Athena_MedConsumable_Parent_C {
	char pad_C09[0x7]; // 0xc09(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc10(0x08)

	void K2_CommitExecute(); // Function GA_Athena_FlopperSmall.GA_Athena_FlopperSmall_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_Athena_FlopperSmall(int32_t EntryPoint); // Function GA_Athena_FlopperSmall.GA_Athena_FlopperSmall_C.ExecuteUbergraph_GA_Athena_FlopperSmall // (Final|UbergraphFunction) // @ game+0xda7c34
};

