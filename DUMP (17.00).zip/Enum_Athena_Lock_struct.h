// UserDefinedEnum Enum_Athena_Lock.Enum_Athena_Lock
enum class Enum_Athena_Lock : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	Enum_Athena_MAX,
};

