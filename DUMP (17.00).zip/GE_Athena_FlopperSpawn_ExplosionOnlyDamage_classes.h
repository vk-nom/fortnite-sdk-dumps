// BlueprintGeneratedClass GE_Athena_FlopperSpawn_ExplosionOnlyDamage.GE_Athena_FlopperSpawn_ExplosionOnlyDamage_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_FlopperSpawn_ExplosionOnlyDamage_C : UGameplayEffect {
};

