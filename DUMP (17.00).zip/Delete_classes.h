// BlueprintGeneratedClass Delete.Delete_C
// Size: 0x28 (Inherited: 0x28)
struct UDelete_C : UInterface {
};

