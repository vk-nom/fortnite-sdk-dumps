// BlueprintGeneratedClass GCN_ValetMod_OffRoadTire_Destroy.GCN_ValetMod_OffRoadTire_Destroy_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_ValetMod_OffRoadTire_Destroy_C : UFortGameplayCueNotify_Burst {
};

