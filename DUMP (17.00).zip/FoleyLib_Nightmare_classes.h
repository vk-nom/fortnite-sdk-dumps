// BlueprintGeneratedClass FoleyLib_Nightmare.FoleyLib_Nightmare_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Nightmare_C : UFoleyLib_Character_Base_C {
};

