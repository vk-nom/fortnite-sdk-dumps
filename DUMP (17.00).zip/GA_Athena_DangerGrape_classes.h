// BlueprintGeneratedClass GA_Athena_DangerGrape.GA_Athena_DangerGrape_C
// Size: 0xe10 (Inherited: 0xe04)
struct UGA_Athena_DangerGrape_C : UGA_Athena_Consumable_Throw_Parent_C {
	char pad_E04[0x4]; // 0xe04(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe08(0x08)

	void K2_ActivateAbility(); // Function GA_Athena_DangerGrape.GA_Athena_DangerGrape_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_Athena_DangerGrape(int32_t EntryPoint); // Function GA_Athena_DangerGrape.GA_Athena_DangerGrape_C.ExecuteUbergraph_GA_Athena_DangerGrape // (Final|UbergraphFunction|HasDefaults) // @ game+0xda7c34
};

