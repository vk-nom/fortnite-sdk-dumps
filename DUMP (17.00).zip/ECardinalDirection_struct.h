// UserDefinedEnum ECardinalDirection.ECardinalDirection
enum class ECardinalDirection : uint8 {
	NewEnumerator0,
	NewEnumerator2,
	NewEnumerator1,
	NewEnumerator3,
	ECardinalDirection_MAX,
};

