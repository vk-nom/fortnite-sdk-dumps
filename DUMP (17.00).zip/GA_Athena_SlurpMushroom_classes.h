// BlueprintGeneratedClass GA_Athena_SlurpMushroom.GA_Athena_SlurpMushroom_C
// Size: 0xc18 (Inherited: 0xc18)
struct UGA_Athena_SlurpMushroom_C : UGA_Athena_ForagedItemVersion_Consume_Parent_C {
};

