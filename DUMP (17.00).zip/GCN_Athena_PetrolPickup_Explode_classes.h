// BlueprintGeneratedClass GCN_Athena_PetrolPickup_Explode.GCN_Athena_PetrolPickup_Explode_C
// Size: 0x1b8 (Inherited: 0x1a8)
struct UGCN_Athena_PetrolPickup_Explode_C : UFortGameplayCueNotify_Burst {
	struct TArray<struct USoundCue*> OverrideSoundCues; // 0x1a8(0x10)

	void OnBurstGeneric(struct AActor* MyTarget, struct FGameplayCueParameters Parameters, struct TArray<struct UFXSystemComponent*> ParticleComponents, struct TArray<struct UAudioComponent*> AudioComponents, struct UMatineeCameraShake* BurstCameraShakeInstance, struct ADecalActor* BurstDecalInstance); // Function GCN_Athena_PetrolPickup_Explode.GCN_Athena_PetrolPickup_Explode_C.OnBurstGeneric // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xda7c34
};

