// BlueprintGeneratedClass Frontend_BattlePass.Frontend_BattlePass_C
// Size: 0x238 (Inherited: 0x238)
struct AFrontend_BattlePass_C : AFortLevelScriptActor {
};

