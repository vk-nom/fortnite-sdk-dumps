// UserDefinedEnum E_Creative_Powerup_LocalVisibility.E_Creative_Powerup_LocalVisibility
enum class E_Creative_Powerup_LocalVisibility : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	E_Creative_Powerup_MAX,
};

