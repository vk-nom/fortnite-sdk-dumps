// WidgetBlueprintGeneratedClass DisplayName.DisplayName_C
// Size: 0x4f8 (Inherited: 0x4e0)
struct UDisplayName_C : UFortDisplayNameWidget {
	struct UCommonBorder* DisplayNameBorder; // 0x4e0(0x08)
	struct UEditableText* EditText_Number; // 0x4e8(0x08)
	struct UVerticalBox* VBox_Number; // 0x4f0(0x08)
};

