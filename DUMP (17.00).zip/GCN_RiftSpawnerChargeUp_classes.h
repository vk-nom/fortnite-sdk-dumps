// BlueprintGeneratedClass GCN_RiftSpawnerChargeUp.GCN_RiftSpawnerChargeUp_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_RiftSpawnerChargeUp_C : UFortGameplayCueNotify_Burst {
};

