// BlueprintGeneratedClass GA_ReactorGrade_Knockback_Nevada.GA_ReactorGrade_Knockback_Nevada_C
// Size: 0xd10 (Inherited: 0xd08)
struct UGA_ReactorGrade_Knockback_Nevada_C : UGA_Athena_Knockback_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd08(0x08)

	void K2_ActivateAbility(); // Function GA_ReactorGrade_Knockback_Nevada.GA_ReactorGrade_Knockback_Nevada_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_ReactorGrade_Knockback_Nevada(int32_t EntryPoint); // Function GA_ReactorGrade_Knockback_Nevada.GA_ReactorGrade_Knockback_Nevada_C.ExecuteUbergraph_GA_ReactorGrade_Knockback_Nevada // (Final|UbergraphFunction) // @ game+0xda7c34
};

