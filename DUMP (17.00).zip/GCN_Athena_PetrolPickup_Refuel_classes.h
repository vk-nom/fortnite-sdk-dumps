// BlueprintGeneratedClass GCN_Athena_PetrolPickup_Refuel.GCN_Athena_PetrolPickup_Refuel_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_Athena_PetrolPickup_Refuel_C : UFortGameplayCueNotify_Burst {

	void OnBurst(struct AActor* MyTarget, struct FGameplayCueParameters Parameters, struct TArray<struct UParticleSystemComponent*> ParticleComponents, struct TArray<struct UAudioComponent*> AudioComponents, struct UMatineeCameraShake* BurstCameraShakeInstance, struct ADecalActor* BurstDecalInstance); // Function GCN_Athena_PetrolPickup_Refuel.GCN_Athena_PetrolPickup_Refuel_C.OnBurst // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xda7c34
};

