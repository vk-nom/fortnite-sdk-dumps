// BlueprintGeneratedClass GA_Ranged_AthenaSniperProjectileImpact.GA_Ranged_AthenaSniperProjectileImpact_C
// Size: 0xab1 (Inherited: 0xab1)
struct UGA_Ranged_AthenaSniperProjectileImpact_C : UGA_Ranged_GenericProjectileImpact_C {
};

