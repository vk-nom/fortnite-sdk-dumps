// SolarisGeneratedEnum Entity_Physics_PhysicsTraceCategory.PhysicsTraceCategory
enum class PhysicsTraceCategory : uint8 {
	Channel,
	Profile,
	Object,
};

