// BlueprintGeneratedClass FortNavArea_JumpDownSmashable3.FortNavArea_JumpDownSmashable3_C
// Size: 0x58 (Inherited: 0x58)
struct UFortNavArea_JumpDownSmashable3_C : UFortNavArea_SmashableJump {
};

