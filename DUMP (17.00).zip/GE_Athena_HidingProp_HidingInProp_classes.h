// BlueprintGeneratedClass GE_Athena_HidingProp_HidingInProp.GE_Athena_HidingProp_HidingInProp_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_HidingProp_HidingInProp_C : UGameplayEffect {
};

