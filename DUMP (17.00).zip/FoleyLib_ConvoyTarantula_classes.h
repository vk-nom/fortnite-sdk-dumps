// BlueprintGeneratedClass FoleyLib_ConvoyTarantula.FoleyLib_ConvoyTarantula_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_ConvoyTarantula_C : UFoleyLib_Character_Base_C {
};

