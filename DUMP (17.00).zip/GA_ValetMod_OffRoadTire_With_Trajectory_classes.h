// BlueprintGeneratedClass GA_ValetMod_OffRoadTire_With_Trajectory.GA_ValetMod_OffRoadTire_With_Trajectory_C
// Size: 0xe2c (Inherited: 0xe2c)
struct UGA_ValetMod_OffRoadTire_With_Trajectory_C : UGA_Athena_UtilityGrenade_WithTrajectory_C {
};

