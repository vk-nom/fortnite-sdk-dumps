// BlueprintGeneratedClass FoleyLib_Kepler.FoleyLib_Kepler_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Kepler_C : UFoleyLib_Character_Base_C {
};

