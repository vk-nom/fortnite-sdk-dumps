// BlueprintGeneratedClass GA_Athena_Scooter_Knockback.GA_Athena_Scooter_Knockback_C
// Size: 0xd08 (Inherited: 0xd08)
struct UGA_Athena_Scooter_Knockback_C : UGA_Athena_Knockback_Parent_C {
};

