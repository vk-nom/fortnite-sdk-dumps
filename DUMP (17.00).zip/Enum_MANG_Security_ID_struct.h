// UserDefinedEnum Enum_MANG_Security_ID.Enum_MANG_Security_ID
enum class Enum_MANG_Security_ID : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	NewEnumerator4,
	NewEnumerator5,
	NewEnumerator6,
	NewEnumerator7,
	NewEnumerator8,
	NewEnumerator9,
	NewEnumerator10,
	Enum_MANG_Security_MAX,
};

