// BlueprintGeneratedClass GA_Athena_UtilityGrenade_WithTrajectory.GA_Athena_UtilityGrenade_WithTrajectory_C
// Size: 0xe2c (Inherited: 0xe2c)
struct UGA_Athena_UtilityGrenade_WithTrajectory_C : UGA_Athena_Grenade_WithTrajectory_C {
};

