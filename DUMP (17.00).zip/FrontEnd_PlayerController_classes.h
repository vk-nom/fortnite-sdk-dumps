// BlueprintGeneratedClass FrontEnd_PlayerController.FrontEnd_PlayerController_C
// Size: 0x26b0 (Inherited: 0x26b0)
struct AFrontEnd_PlayerController_C : AFortPlayerControllerFrontEnd {
};

