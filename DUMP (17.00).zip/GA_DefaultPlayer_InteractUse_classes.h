// BlueprintGeneratedClass GA_DefaultPlayer_InteractUse.GA_DefaultPlayer_InteractUse_C
// Size: 0xa78 (Inherited: 0xa70)
struct UGA_DefaultPlayer_InteractUse_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)

	void OnCancelled_A513E1E044E129CC612DF5A23589BC9C(); // Function GA_DefaultPlayer_InteractUse.GA_DefaultPlayer_InteractUse_C.OnCancelled_A513E1E044E129CC612DF5A23589BC9C // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnInterrupted_A513E1E044E129CC612DF5A23589BC9C(); // Function GA_DefaultPlayer_InteractUse.GA_DefaultPlayer_InteractUse_C.OnInterrupted_A513E1E044E129CC612DF5A23589BC9C // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnBlendOut_A513E1E044E129CC612DF5A23589BC9C(); // Function GA_DefaultPlayer_InteractUse.GA_DefaultPlayer_InteractUse_C.OnBlendOut_A513E1E044E129CC612DF5A23589BC9C // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnCompleted_A513E1E044E129CC612DF5A23589BC9C(); // Function GA_DefaultPlayer_InteractUse.GA_DefaultPlayer_InteractUse_C.OnCompleted_A513E1E044E129CC612DF5A23589BC9C // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void K2_ActivateAbility(); // Function GA_DefaultPlayer_InteractUse.GA_DefaultPlayer_InteractUse_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_DefaultPlayer_InteractUse(int32_t EntryPoint); // Function GA_DefaultPlayer_InteractUse.GA_DefaultPlayer_InteractUse_C.ExecuteUbergraph_GA_DefaultPlayer_InteractUse // (Final|UbergraphFunction) // @ game+0xda7c34
};

