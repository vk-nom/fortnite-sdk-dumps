// UserDefinedEnum Enum_BoostJumpStates.Enum_BoostJumpStates
enum class Enum_BoostJumpStates : uint8 {
	NewEnumerator3,
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator4,
	Enum_MAX,
};

