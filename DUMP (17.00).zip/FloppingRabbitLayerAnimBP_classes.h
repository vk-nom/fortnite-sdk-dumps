// AnimBlueprintGeneratedClass FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C
// Size: 0x2771 (Inherited: 0x3f0)
struct UFloppingRabbitLayerAnimBP_C : UFortItemLayerAnimInstance_FullLocomotion {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root_35; // 0x3f8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_19; // 0x428(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_34; // 0x540(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_18; // 0x570(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_33; // 0x688(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_17; // 0x6b8(0x118)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_16; // 0x7d0(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_32; // 0x8e8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_15; // 0x918(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_31; // 0xa30(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_10; // 0xa60(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_5; // 0xae0(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9; // 0xb80(0x80)
	struct FAnimNode_Root AnimGraphNode_Root_30; // 0xc00(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8; // 0xc30(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_4; // 0xcb0(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7; // 0xd50(0x80)
	struct FAnimNode_Root AnimGraphNode_Root_29; // 0xdd0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0xe00(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3; // 0xe80(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0xf20(0x80)
	struct FAnimNode_Root AnimGraphNode_Root_28; // 0xfa0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0xfd0(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x1050(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x10f0(0x80)
	struct FAnimNode_Root AnimGraphNode_Root_27; // 0x1170(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_14; // 0x11a0(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_26; // 0x12b8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_13; // 0x12e8(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_25; // 0x1400(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_12; // 0x1430(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_24; // 0x1548(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_23; // 0x1578(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_22; // 0x15a8(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_21; // 0x15d8(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_20; // 0x1608(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_19; // 0x1638(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_18; // 0x1668(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_17; // 0x1698(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_16; // 0x16c8(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_15; // 0x16f8(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_14; // 0x1728(0x30)
	struct FAnimNode_Root AnimGraphNode_Root_13; // 0x1758(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_11; // 0x1788(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_12; // 0x18a0(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_10; // 0x18d0(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_11; // 0x19e8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_9; // 0x1a18(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_10; // 0x1b30(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_8; // 0x1b60(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_9; // 0x1c78(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_7; // 0x1ca8(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_8; // 0x1dc0(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_6; // 0x1df0(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_7; // 0x1f08(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_5; // 0x1f38(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_6; // 0x2050(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_4; // 0x2080(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_5; // 0x2198(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_3; // 0x21c8(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_4; // 0x22e0(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_2; // 0x2310(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_3; // 0x2428(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose; // 0x2458(0x118)
	struct FAnimNode_Root AnimGraphNode_Root_2; // 0x2570(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x25a0(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x2620(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x26c0(0x80)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2740(0x30)
	bool OneHandGrip; // 0x2770(0x01)

	void ItemPreIK(struct FPoseLink InPose_PreIK, struct FPoseLink ItemPreIK); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemPreIK // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemFullBodyOverride(struct FPoseLink InPoseFullBody, struct FPoseLink ItemFullBodyOverride); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemFullBodyOverride // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemAimOffset(struct FPoseLink InPose_AimOffset, float AimOffsetAlpha, float Yaw, float Pitch, struct FPoseLink InPose_UpperLowerPreMeleeAO, struct FPoseLink ItemAimOffset); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemAimOffset // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemSkeletalControl(struct FPoseLink InPose, struct FPoseLink ItemSkeletalControl); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemSkeletalControl // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemSwimJumpSurfaceEnd(struct FPoseLink ItemSwimJumpSurfaceEnd); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemSwimJumpSurfaceEnd // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemSwimJumpSurfaceLoop(struct FPoseLink ItemSwimJumpSurfaceLoop); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemSwimJumpSurfaceLoop // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemSwimJumpFallLoop(struct FPoseLink ItemSwimJumpFallLoop); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemSwimJumpFallLoop // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemSwimJumpStartLoop(struct FPoseLink ItemSwimJumpStartLoop); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemSwimJumpStartLoop // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemUpperBody(struct FPoseLink InPoseUpperBody, struct FFortAnimInput_AdjustedAim InputParam, struct FPoseLink ItemUpperBody); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemUpperBody // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemFullBodySprint(struct FPoseLink InPoseSprint, struct FPoseLink ItemFullBodySprint); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemFullBodySprint // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemIdleAdditive(struct FPoseLink InPoseIdleAdditive, struct FPoseLink ItemIdleAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemIdleAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemCrouchTurningAdditive(struct FPoseLink ItemCrouchTurningAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemCrouchTurningAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemSlopeSliding(struct FPoseLink ItemSlopeSliding); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemSlopeSliding // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemJumpUpAdditive(struct FPoseLink ItemJumpUpAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemJumpUpAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemJumpLoopAdditive(struct FPoseLink ItemJumpLoopAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemJumpLoopAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemFallAdditive(struct FPoseLink ItemFallAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemFallAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemFallLandAdditive(struct FPoseLink ItemFallLandAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemFallLandAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemJetPackStartAdditive(struct FPoseLink ItemJetPackStartAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemJetPackStartAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemJetPackJumpAdditive(struct FPoseLink ItemJetPackJumpAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemJetPackJumpAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemZipLineStartAdditive(struct FPoseLink ItemZipLineStartAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemZipLineStartAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemFlyModeStartAdditive(struct FPoseLink ItemFlyModeStartAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemFlyModeStartAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemFlyModeLoopAdditive(struct FPoseLink ItemFlyModeLoopAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemFlyModeLoopAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemJogStartAdditive(struct FPoseLink InPoseJogStartAdditive, struct FPoseLink ItemJogStartAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemJogStartAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemJogStopAdditive(struct FPoseLink InPoseJogStopAdditive, struct FPoseLink ItemJogStopAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemJogStopAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemJogPrePivotAdditive(struct FPoseLink InPosePrePivotAdditive, struct FPoseLink ItemJogPrePivotAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemJogPrePivotAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemJogPostPivotAdditive(struct FPoseLink InPosePostPivotAdditive, struct FPoseLink ItemJogPostPivotAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemJogPostPivotAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemLowerBodyMovement(struct FPoseLink InPoseLowerBodyMovement, struct FPoseLink ItemLowerBodyMovement); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemLowerBodyMovement // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemLowerBodyLeanAdditive(struct FPoseLink InPoseLowerBodyLeanAdditive, struct FPoseLink ItemLowerBodyLeanAdditive); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemLowerBodyLeanAdditive // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemLowerBodyJogStart(struct FPoseLink InPoseLowerBodyJogStart, struct FPoseLink ItemLowerBodyJogStart); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemLowerBodyJogStart // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemLowerBodyJogStop(struct FPoseLink InPoseLowerBodyJogStop, struct FPoseLink ItemLowerBodyJogStop); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemLowerBodyJogStop // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemLowerBodyJogPrePivot(struct FPoseLink InPoseLowerBodyJogPrePivot, struct FPoseLink ItemLowerBodyJogPrePivot); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemLowerBodyJogPrePivot // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemLowerBodyJogPostPivot(struct FPoseLink InPoseLowerBodyJogPostPivot, struct FPoseLink ItemLowerBodyJogPostPivot); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemLowerBodyJogPostPivot // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemRelaxedEntry(struct FPoseLink InPoseRelaxedEntry, struct FPoseLink ItemRelaxedEntry); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemRelaxedEntry // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void ItemSwimJumpStart(struct FPoseLink ItemSwimJumpStart); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ItemSwimJumpStart // (HasOutParms|BlueprintCallable) // @ game+0xda7c34
	void AnimGraph(struct FPoseLink AnimGraph); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_FloppingRabbitLayerAnimBP(int32_t EntryPoint); // Function FloppingRabbitLayerAnimBP.FloppingRabbitLayerAnimBP_C.ExecuteUbergraph_FloppingRabbitLayerAnimBP // (Final|UbergraphFunction) // @ game+0xda7c34
};

