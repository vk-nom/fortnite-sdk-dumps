// BlueprintGeneratedClass GCN_CollisionEffects_Boulder.GCN_CollisionEffects_Boulder_C
// Size: 0x1e8 (Inherited: 0x1e8)
struct UGCN_CollisionEffects_Boulder_C : UGCN_CollisionEffects_Parent_C {
};

