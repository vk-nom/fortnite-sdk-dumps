// BlueprintGeneratedClass GA_Athena_ShieldSmall.GA_Athena_ShieldSmall_C
// Size: 0xc09 (Inherited: 0xc09)
struct UGA_Athena_ShieldSmall_C : UGA_Athena_MedConsumable_Parent_C {
};

