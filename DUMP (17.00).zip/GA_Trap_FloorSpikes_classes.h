// BlueprintGeneratedClass GA_Trap_FloorSpikes.GA_Trap_FloorSpikes_C
// Size: 0xa90 (Inherited: 0xa90)
struct UGA_Trap_FloorSpikes_C : UGA_TrapGeneric_C {
};

