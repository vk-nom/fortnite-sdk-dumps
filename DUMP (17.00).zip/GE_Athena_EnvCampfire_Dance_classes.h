// BlueprintGeneratedClass GE_Athena_EnvCampfire_Dance.GE_Athena_EnvCampfire_Dance_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_EnvCampfire_Dance_C : UGameplayEffect {
};

