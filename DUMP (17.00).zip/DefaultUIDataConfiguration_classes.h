// BlueprintGeneratedClass DefaultUIDataConfiguration.DefaultUIDataConfiguration_C
// Size: 0x3e68 (Inherited: 0x3e68)
struct UDefaultUIDataConfiguration_C : UFortUIDataConfiguration {
};

