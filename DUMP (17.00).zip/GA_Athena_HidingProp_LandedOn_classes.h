// BlueprintGeneratedClass GA_Athena_HidingProp_LandedOn.GA_Athena_HidingProp_LandedOn_C
// Size: 0xaa0 (Inherited: 0xa70)
struct UGA_Athena_HidingProp_LandedOn_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)
	struct FScalableFloat HidingEnabled; // 0xa78(0x28)

	void K2_ActivateAbilityFromEvent(struct FGameplayEventData EventData); // Function GA_Athena_HidingProp_LandedOn.GA_Athena_HidingProp_LandedOn_C.K2_ActivateAbilityFromEvent // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_Athena_HidingProp_LandedOn(int32_t EntryPoint); // Function GA_Athena_HidingProp_LandedOn.GA_Athena_HidingProp_LandedOn_C.ExecuteUbergraph_GA_Athena_HidingProp_LandedOn // (Final|UbergraphFunction|HasDefaults) // @ game+0xda7c34
};

