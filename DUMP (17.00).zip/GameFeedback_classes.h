// Class GameFeedback.LogOptions
// Size: 0x38 (Inherited: 0x28)
struct ULogOptions : UObject {
	struct TArray<struct FLogSubmitOptions> LogOptions; // 0x28(0x10)
};

