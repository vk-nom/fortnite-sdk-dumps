// BlueprintGeneratedClass FortNavArea_JumpDown.FortNavArea_JumpDown_C
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_JumpDown_C : UFortNavArea {
};

