// BlueprintGeneratedClass GCNL_Dagwood_Speedlines.GCNL_Dagwood_Speedlines_C
// Size: 0x7d0 (Inherited: 0x7d0)
struct AGCNL_Dagwood_Speedlines_C : AFortGameplayCueNotify_Loop {
};

