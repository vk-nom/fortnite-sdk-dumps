// BlueprintGeneratedClass GCN_RiftSpawnFiend.GCN_RiftSpawnFiend_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_RiftSpawnFiend_C : UFortGameplayCueNotify_Burst {

	void OnBurst(struct AActor* MyTarget, struct FGameplayCueParameters Parameters, struct TArray<struct UParticleSystemComponent*> ParticleComponents, struct TArray<struct UAudioComponent*> AudioComponents, struct UMatineeCameraShake* BurstCameraShakeInstance, struct ADecalActor* BurstDecalInstance); // Function GCN_RiftSpawnFiend.GCN_RiftSpawnFiend_C.OnBurst // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xda7c34
};

