// Class FortSoundCueTemplates.FortSoundCueTemplateBase
// Size: 0x550 (Inherited: 0x550)
struct UFortSoundCueTemplateBase : USoundCueTemplate {
};

// Class FortSoundCueTemplates.EmoteBase
// Size: 0x550 (Inherited: 0x550)
struct UEmoteBase : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.EmoteFoley
// Size: 0x550 (Inherited: 0x550)
struct UEmoteFoley : UEmoteBase {
};

// Class FortSoundCueTemplates.EmoteMusic
// Size: 0x550 (Inherited: 0x550)
struct UEmoteMusic : UEmoteBase {
};

// Class FortSoundCueTemplates.EmoteMusic3P
// Size: 0x550 (Inherited: 0x550)
struct UEmoteMusic3P : UEmoteBase {
};

// Class FortSoundCueTemplates.GliderOpenClose
// Size: 0x550 (Inherited: 0x550)
struct UGliderOpenClose : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.GliderOpen
// Size: 0x550 (Inherited: 0x550)
struct UGliderOpen : UGliderOpenClose {
};

// Class FortSoundCueTemplates.GliderClose
// Size: 0x550 (Inherited: 0x550)
struct UGliderClose : UGliderOpenClose {
};

// Class FortSoundCueTemplates.GliderThrustLoop
// Size: 0x550 (Inherited: 0x550)
struct UGliderThrustLoop : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.GliderThrustStart
// Size: 0x550 (Inherited: 0x550)
struct UGliderThrustStart : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.MusicPack
// Size: 0x550 (Inherited: 0x550)
struct UMusicPack : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PhysicsStateLoop
// Size: 0x550 (Inherited: 0x550)
struct UPhysicsStateLoop : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PhysicsImpact
// Size: 0x550 (Inherited: 0x550)
struct UPhysicsImpact : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PickaxeBase
// Size: 0x550 (Inherited: 0x550)
struct UPickaxeBase : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PickaxeImpactEnemy
// Size: 0x550 (Inherited: 0x550)
struct UPickaxeImpactEnemy : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PickaxeReady
// Size: 0x550 (Inherited: 0x550)
struct UPickaxeReady : UPickaxeBase {
};

// Class FortSoundCueTemplates.PickaxeSwing
// Size: 0x550 (Inherited: 0x550)
struct UPickaxeSwing : UPickaxeBase {
};

