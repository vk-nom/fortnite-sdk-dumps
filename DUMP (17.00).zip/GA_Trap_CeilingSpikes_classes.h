// BlueprintGeneratedClass GA_Trap_CeilingSpikes.GA_Trap_CeilingSpikes_C
// Size: 0xa90 (Inherited: 0xa90)
struct UGA_Trap_CeilingSpikes_C : UGA_TrapGeneric_C {
};

