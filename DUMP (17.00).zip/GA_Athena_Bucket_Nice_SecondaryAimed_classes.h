// BlueprintGeneratedClass GA_Athena_Bucket_Nice_SecondaryAimed.GA_Athena_Bucket_Nice_SecondaryAimed_C
// Size: 0xe60 (Inherited: 0xe60)
struct UGA_Athena_Bucket_Nice_SecondaryAimed_C : UGA_Athena_Bucket_Old_SecondaryAimed_C {
};

