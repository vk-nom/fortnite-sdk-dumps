// BlueprintGeneratedClass GA_HeldObject_Throw_Component_AI.GA_HeldObject_Throw_Component_AI_C
// Size: 0xc50 (Inherited: 0xc50)
struct UGA_HeldObject_Throw_Component_AI_C : UGA_HeldObject_Throw_Component_C {

	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer RelevantTags); // Function GA_HeldObject_Throw_Component_AI.GA_HeldObject_Throw_Component_AI_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xda7c34
};

