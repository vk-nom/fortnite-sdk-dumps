// BlueprintGeneratedClass FireMaterialInteractHandler.FireMaterialInteractHandler_C
// Size: 0x98 (Inherited: 0x98)
struct UFireMaterialInteractHandler_C : UFortCurieElementInteractWithMaterialHandlerFire {
};

