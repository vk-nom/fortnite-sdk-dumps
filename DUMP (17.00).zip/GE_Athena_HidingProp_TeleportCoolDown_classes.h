// BlueprintGeneratedClass GE_Athena_HidingProp_TeleportCoolDown.GE_Athena_HidingProp_TeleportCoolDown_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_HidingProp_TeleportCoolDown_C : UGameplayEffect {
};

