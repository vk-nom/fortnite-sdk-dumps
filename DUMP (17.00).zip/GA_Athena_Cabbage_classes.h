// BlueprintGeneratedClass GA_Athena_Cabbage.GA_Athena_Cabbage_C
// Size: 0xc18 (Inherited: 0xc18)
struct UGA_Athena_Cabbage_C : UGA_Athena_ForagedItemVersion_Consume_Parent_C {
};

