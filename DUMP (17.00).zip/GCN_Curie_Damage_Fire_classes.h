// BlueprintGeneratedClass GCN_Curie_Damage_Fire.GCN_Curie_Damage_Fire_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_Curie_Damage_Fire_C : UFortGameplayCueNotify_Burst {
};

