// BlueprintGeneratedClass FoleyLib_Hightower_Wasabi.FoleyLib_Hightower_Wasabi_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Hightower_Wasabi_C : UFoleyLib_Character_Base_C {
};

