// UserDefinedStruct FlowMapMaterials.FlowMapMaterials
// Size: 0x10 (Inherited: 0x00)
struct FFlowMapMaterials {
	struct UMaterialInterface* OriginalMaterial_4_C9560D9C4A128A0A813E97865710CC97; // 0x00(0x08)
	struct UMaterialInterface* RenderToTextureMaterial_5_5CB972A744E80375B62CF68122B83C88; // 0x08(0x08)
};

