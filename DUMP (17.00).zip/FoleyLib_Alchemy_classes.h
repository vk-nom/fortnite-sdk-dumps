// BlueprintGeneratedClass FoleyLib_Alchemy.FoleyLib_Alchemy_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Alchemy_C : UFoleyLib_Character_Base_C {
};

