// UserDefinedEnum EIntTypes.EIntTypes
enum class EIntTypes : uint8 {
	NewEnumerator4,
	NewEnumerator5,
	NewEnumerator6,
	NewEnumerator7,
	EIntTypes_MAX,
};

