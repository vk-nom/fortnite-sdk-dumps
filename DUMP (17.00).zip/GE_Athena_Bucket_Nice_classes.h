// BlueprintGeneratedClass GE_Athena_Bucket_Nice.GE_Athena_Bucket_Nice_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_Bucket_Nice_C : UGE_Athena_Bucket_Old_C {
};

