// SolarisGeneratedEnum Entity_Physics_PhysicsTraceShape.PhysicsTraceShape
enum class PhysicsTraceShape : uint8 {
	Line,
	Box,
	ShapeSphere,
};

