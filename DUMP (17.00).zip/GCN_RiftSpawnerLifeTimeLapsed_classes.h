// BlueprintGeneratedClass GCN_RiftSpawnerLifeTimeLapsed.GCN_RiftSpawnerLifeTimeLapsed_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_RiftSpawnerLifeTimeLapsed_C : UFortGameplayCueNotify_Burst {
};

