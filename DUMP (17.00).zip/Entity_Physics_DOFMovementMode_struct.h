// SolarisGeneratedEnum Entity_Physics_DOFMovementMode.DOFMovementMode
enum class DOFMovementMode : uint8 {
	Default,
	SixDOF,
	YZPlane,
	XZPlane,
	XYPlane,
	CustomPlane,
	NoConstraints,
};

