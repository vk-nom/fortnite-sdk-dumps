// BlueprintGeneratedClass FoleyLib_Hightower_Date.FoleyLib_Hightower_Date_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Hightower_Date_C : UFoleyLib_Character_Base_C {
};

