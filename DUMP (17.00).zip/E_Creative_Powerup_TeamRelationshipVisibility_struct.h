// UserDefinedEnum E_Creative_Powerup_TeamRelationshipVisibility.E_Creative_Powerup_TeamRelationshipVisibility
enum class E_Creative_Powerup_TeamRelationshipVisibility : uint8 {
	NewEnumerator1,
	NewEnumerator0,
	E_Creative_Powerup_MAX,
};

