// BlueprintGeneratedClass GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C
// Size: 0xa78 (Inherited: 0xa70)
struct UGA_Athena_Player_Ragdoll_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)

	void OnNotifyEnd_461EDAFF4994509313085790267AF56D(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnNotifyEnd_461EDAFF4994509313085790267AF56D // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnNotifyBegin_461EDAFF4994509313085790267AF56D(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnNotifyBegin_461EDAFF4994509313085790267AF56D // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnCancelled_461EDAFF4994509313085790267AF56D(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnCancelled_461EDAFF4994509313085790267AF56D // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnInterrupted_461EDAFF4994509313085790267AF56D(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnInterrupted_461EDAFF4994509313085790267AF56D // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnBlendOut_461EDAFF4994509313085790267AF56D(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnBlendOut_461EDAFF4994509313085790267AF56D // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnCompleted_461EDAFF4994509313085790267AF56D(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnCompleted_461EDAFF4994509313085790267AF56D // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnNotifyEnd_14A1224A4375D017D9C6A49E475BE1FD(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnNotifyEnd_14A1224A4375D017D9C6A49E475BE1FD // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnNotifyBegin_14A1224A4375D017D9C6A49E475BE1FD(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnNotifyBegin_14A1224A4375D017D9C6A49E475BE1FD // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnCancelled_14A1224A4375D017D9C6A49E475BE1FD(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnCancelled_14A1224A4375D017D9C6A49E475BE1FD // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnInterrupted_14A1224A4375D017D9C6A49E475BE1FD(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnInterrupted_14A1224A4375D017D9C6A49E475BE1FD // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnBlendOut_14A1224A4375D017D9C6A49E475BE1FD(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnBlendOut_14A1224A4375D017D9C6A49E475BE1FD // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnCompleted_14A1224A4375D017D9C6A49E475BE1FD(struct FGameplayTag NotifyTag); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.OnCompleted_14A1224A4375D017D9C6A49E475BE1FD // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void Removed_7DFF60D446294863E8833093A16B8EF8(); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.Removed_7DFF60D446294863E8833093A16B8EF8 // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void K2_ActivateAbility(); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void K2_OnEndAbility(bool bWasCancelled); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_Athena_Player_Ragdoll(int32_t EntryPoint); // Function GA_Athena_Player_Ragdoll.GA_Athena_Player_Ragdoll_C.ExecuteUbergraph_GA_Athena_Player_Ragdoll // (Final|UbergraphFunction|HasDefaults) // @ game+0xda7c34
};

