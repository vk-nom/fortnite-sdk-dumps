// BlueprintGeneratedClass GE_Athena_Campfire_Heal.GE_Athena_Campfire_Heal_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_Campfire_Heal_C : UGameplayEffect {
};

