// BlueprintGeneratedClass GCN_Burst_Hot_Feet_Environmental.GCN_Burst_Hot_Feet_Environmental_C
// Size: 0x1a9 (Inherited: 0x1a8)
struct UGCN_Burst_Hot_Feet_Environmental_C : UFortGameplayCueNotify_Burst {
	bool NewVar_1; // 0x1a8(0x01)
};

