// SolarisGeneratedClass Diagnostics_assert.assert
// Size: 0x28 (Inherited: 0x28)
struct Uassert : UObject {

	void cmpMsg(char __verse_0x123742AA_expression, struct FString __verse_0xD212B012_message); // Function Diagnostics_assert.assert.cmpMsg // (Native|Static|Public|BlueprintCallable) // @ game+0x4347640
	void cmp(char __verse_0x123742AA_expression); // Function Diagnostics_assert.assert.cmp // (Native|Static|Public|BlueprintCallable) // @ game+0x4347648
	void $InitCDO(); // Function Diagnostics_assert.assert.$InitCDO // (None) // @ game+0xda7c34
};

