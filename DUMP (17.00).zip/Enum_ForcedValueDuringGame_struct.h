// UserDefinedEnum Enum_ForcedValueDuringGame.Enum_ForcedValueDuringGame
enum class Enum_ForcedValueDuringGame : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	Enum_MAX,
};

