// BlueprintGeneratedClass GE_Athena_Coconut_Health.GE_Athena_Coconut_Health_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_Coconut_Health_C : UGameplayEffect {
};

