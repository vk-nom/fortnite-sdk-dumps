// BlueprintGeneratedClass GA_Trap_WallSpikesMetal.GA_Trap_WallSpikesMetal_C
// Size: 0xa90 (Inherited: 0xa90)
struct UGA_Trap_WallSpikesMetal_C : UGA_TrapGeneric_C {
};

