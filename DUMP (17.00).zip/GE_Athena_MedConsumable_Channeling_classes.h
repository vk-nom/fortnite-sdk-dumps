// BlueprintGeneratedClass GE_Athena_MedConsumable_Channeling.GE_Athena_MedConsumable_Channeling_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_MedConsumable_Channeling_C : UGameplayEffect {
};

