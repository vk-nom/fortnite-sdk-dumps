// BlueprintGeneratedClass GE_Athena_HidingProp_Teleporting.GE_Athena_HidingProp_Teleporting_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_HidingProp_Teleporting_C : UGameplayEffect {
};

