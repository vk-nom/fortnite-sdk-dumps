// BlueprintGeneratedClass GA_HeldObject_Drop.GA_HeldObject_Drop_C
// Size: 0xa78 (Inherited: 0xa70)
struct UGA_HeldObject_Drop_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)

	void K2_ActivateAbility(); // Function GA_HeldObject_Drop.GA_HeldObject_Drop_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_HeldObject_Drop(int32_t EntryPoint); // Function GA_HeldObject_Drop.GA_HeldObject_Drop_C.ExecuteUbergraph_GA_HeldObject_Drop // (Final|UbergraphFunction) // @ game+0xda7c34
};

