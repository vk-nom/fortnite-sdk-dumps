// BlueprintGeneratedClass GCN_UnstableBow_Intro.GCN_UnstableBow_Intro_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_UnstableBow_Intro_C : UFortGameplayCueNotify_Burst {
};

