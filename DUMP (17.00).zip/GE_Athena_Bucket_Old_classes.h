// BlueprintGeneratedClass GE_Athena_Bucket_Old.GE_Athena_Bucket_Old_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_Bucket_Old_C : UGet_DirectDamageParent_C {
};

