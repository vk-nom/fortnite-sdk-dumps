// BlueprintGeneratedClass FoleyLib_Cosmos.FoleyLib_Cosmos_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Cosmos_C : UFoleyLib_Character_Base_C {
};

