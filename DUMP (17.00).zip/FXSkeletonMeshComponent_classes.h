// BlueprintGeneratedClass FXSkeletonMeshComponent.FXSkeletonMeshComponent_C
// Size: 0xef0 (Inherited: 0xef0)
struct UFXSkeletonMeshComponent_C : UFortFXSkeletonMeshComponent {

	void ApplyAwakenEffect(); // Function FXSkeletonMeshComponent.FXSkeletonMeshComponent_C.ApplyAwakenEffect // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void ApplyEffect(struct UMaterialInterface* SourceMaterial, float FadeInTime, float Duration, float FadeOutTime); // Function FXSkeletonMeshComponent.FXSkeletonMeshComponent_C.ApplyEffect // (Protected|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void ApplyBuildingHitEffect(); // Function FXSkeletonMeshComponent.FXSkeletonMeshComponent_C.ApplyBuildingHitEffect // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
};

