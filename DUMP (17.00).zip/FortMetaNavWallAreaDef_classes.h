// BlueprintGeneratedClass FortMetaNavWallAreaDef.FortMetaNavWallAreaDef_C
// Size: 0x58 (Inherited: 0x58)
struct UFortMetaNavWallAreaDef_C : UFortMetaNavArea_Wall {
};

