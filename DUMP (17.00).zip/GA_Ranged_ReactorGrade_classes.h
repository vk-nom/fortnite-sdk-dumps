// BlueprintGeneratedClass GA_Ranged_ReactorGrade.GA_Ranged_ReactorGrade_C
// Size: 0xabc (Inherited: 0xab1)
struct UGA_Ranged_ReactorGrade_C : UGA_Ranged_GenericDamage_C {
	char pad_AB1[0x3]; // 0xab1(0x03)
	struct FGameplayTag Gameplay Cue Tag; // 0xab4(0x08)
};

