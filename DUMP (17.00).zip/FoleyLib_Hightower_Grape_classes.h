// BlueprintGeneratedClass FoleyLib_Hightower_Grape.FoleyLib_Hightower_Grape_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Hightower_Grape_C : UFoleyLib_Character_Base_C {
};

