// UserDefinedEnum EEnabledState.EEnabledState
enum class EEnabledState : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	EEnabledState_MAX,
};

