// BlueprintGeneratedClass FoleyLib_AncientGladiator_Male_Light.FoleyLib_AncientGladiator_Male_Light_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_AncientGladiator_Male_Light_C : UFoleyLib_Character_Base_C {
};

