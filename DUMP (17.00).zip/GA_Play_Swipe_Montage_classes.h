// BlueprintGeneratedClass GA_Play_Swipe_Montage.GA_Play_Swipe_Montage_C
// Size: 0xa78 (Inherited: 0xa70)
struct UGA_Play_Swipe_Montage_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)

	void OnCancelled_72D325494FA9FD623AC13DA17B9ACCEF(); // Function GA_Play_Swipe_Montage.GA_Play_Swipe_Montage_C.OnCancelled_72D325494FA9FD623AC13DA17B9ACCEF // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnInterrupted_72D325494FA9FD623AC13DA17B9ACCEF(); // Function GA_Play_Swipe_Montage.GA_Play_Swipe_Montage_C.OnInterrupted_72D325494FA9FD623AC13DA17B9ACCEF // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnBlendOut_72D325494FA9FD623AC13DA17B9ACCEF(); // Function GA_Play_Swipe_Montage.GA_Play_Swipe_Montage_C.OnBlendOut_72D325494FA9FD623AC13DA17B9ACCEF // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnCompleted_72D325494FA9FD623AC13DA17B9ACCEF(); // Function GA_Play_Swipe_Montage.GA_Play_Swipe_Montage_C.OnCompleted_72D325494FA9FD623AC13DA17B9ACCEF // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void K2_ActivateAbility(); // Function GA_Play_Swipe_Montage.GA_Play_Swipe_Montage_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_Play_Swipe_Montage(int32_t EntryPoint); // Function GA_Play_Swipe_Montage.GA_Play_Swipe_Montage_C.ExecuteUbergraph_GA_Play_Swipe_Montage // (Final|UbergraphFunction) // @ game+0xda7c34
};

