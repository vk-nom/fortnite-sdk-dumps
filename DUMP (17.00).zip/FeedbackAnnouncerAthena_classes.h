// BlueprintGeneratedClass FeedbackAnnouncerAthena.FeedbackAnnouncerAthena_C
// Size: 0x1290 (Inherited: 0x1290)
struct AFeedbackAnnouncerAthena_C : AFortPawn_FeedbackAnnouncer {
};

