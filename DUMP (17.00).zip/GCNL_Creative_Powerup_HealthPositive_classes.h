// BlueprintGeneratedClass GCNL_Creative_Powerup_HealthPositive.GCNL_Creative_Powerup_HealthPositive_C
// Size: 0x7d0 (Inherited: 0x7d0)
struct AGCNL_Creative_Powerup_HealthPositive_C : AFortGameplayCueNotify_Loop {
};

