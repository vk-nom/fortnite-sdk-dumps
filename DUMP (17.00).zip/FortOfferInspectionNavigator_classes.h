// WidgetBlueprintGeneratedClass FortOfferInspectionNavigator.FortOfferInspectionNavigator_C
// Size: 0x340 (Inherited: 0x340)
struct UFortOfferInspectionNavigator_C : UAthenaItemShopOfferInspectionNavigator {
};

