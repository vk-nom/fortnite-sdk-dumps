// UserDefinedEnum E_DataTrackerTagTypes.E_DataTrackerTagTypes
enum class E_DataTrackerTagTypes : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	E_MAX,
};

