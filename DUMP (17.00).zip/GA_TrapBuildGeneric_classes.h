// BlueprintGeneratedClass GA_TrapBuildGeneric.GA_TrapBuildGeneric_C
// Size: 0xa80 (Inherited: 0xa70)
struct UGA_TrapBuildGeneric_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)
	struct FGameplayTag PlacedCue; // 0xa78(0x08)

	void K2_ActivateAbility(); // Function GA_TrapBuildGeneric.GA_TrapBuildGeneric_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_TrapBuildGeneric(int32_t EntryPoint); // Function GA_TrapBuildGeneric.GA_TrapBuildGeneric_C.ExecuteUbergraph_GA_TrapBuildGeneric // (Final|UbergraphFunction|HasDefaults) // @ game+0xda7c34
};

