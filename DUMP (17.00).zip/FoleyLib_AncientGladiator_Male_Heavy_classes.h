// BlueprintGeneratedClass FoleyLib_AncientGladiator_Male_Heavy.FoleyLib_AncientGladiator_Male_Heavy_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_AncientGladiator_Male_Heavy_C : UFoleyLib_Character_Base_C {
};

