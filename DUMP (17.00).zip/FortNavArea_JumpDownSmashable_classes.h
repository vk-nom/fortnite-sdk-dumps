// BlueprintGeneratedClass FortNavArea_JumpDownSmashable.FortNavArea_JumpDownSmashable_C
// Size: 0x58 (Inherited: 0x58)
struct UFortNavArea_JumpDownSmashable_C : UFortNavArea_SmashableJump {
};

