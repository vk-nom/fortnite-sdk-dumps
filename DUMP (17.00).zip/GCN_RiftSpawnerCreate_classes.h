// BlueprintGeneratedClass GCN_RiftSpawnerCreate.GCN_RiftSpawnerCreate_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_RiftSpawnerCreate_C : UFortGameplayCueNotify_Burst {
};

