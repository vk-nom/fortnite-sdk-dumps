// BlueprintGeneratedClass GE_Athena_Lockout.GE_Athena_Lockout_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_Lockout_C : UGameplayEffect {
};

