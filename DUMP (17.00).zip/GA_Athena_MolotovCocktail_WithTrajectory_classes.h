// BlueprintGeneratedClass GA_Athena_MolotovCocktail_WithTrajectory.GA_Athena_MolotovCocktail_WithTrajectory_C
// Size: 0xe04 (Inherited: 0xe04)
struct UGA_Athena_MolotovCocktail_WithTrajectory_C : UGA_Athena_Consumable_Throw_Parent_C {
};

