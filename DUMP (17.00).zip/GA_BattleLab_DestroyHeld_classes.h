// BlueprintGeneratedClass GA_BattleLab_DestroyHeld.GA_BattleLab_DestroyHeld_C
// Size: 0xa78 (Inherited: 0xa70)
struct UGA_BattleLab_DestroyHeld_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)

	void K2_ActivateAbility(); // Function GA_BattleLab_DestroyHeld.GA_BattleLab_DestroyHeld_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_BattleLab_DestroyHeld(int32_t EntryPoint); // Function GA_BattleLab_DestroyHeld.GA_BattleLab_DestroyHeld_C.ExecuteUbergraph_GA_BattleLab_DestroyHeld // (Final|UbergraphFunction) // @ game+0xda7c34
};

