// BlueprintGeneratedClass GA_Ranged_FireExtinguisher_Projectile_Athena.GA_Ranged_FireExtinguisher_Projectile_Athena_C
// Size: 0xab1 (Inherited: 0xab1)
struct UGA_Ranged_FireExtinguisher_Projectile_Athena_C : UGA_Ranged_GenericProjectileExplosive_C {
};

