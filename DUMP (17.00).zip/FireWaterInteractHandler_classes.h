// BlueprintGeneratedClass FireWaterInteractHandler.FireWaterInteractHandler_C
// Size: 0x88 (Inherited: 0x88)
struct UFireWaterInteractHandler_C : UFortCurieElementInteractWithElementHandler {
};

