// BlueprintGeneratedClass FrontendItemViewSettingsManager.FrontendItemViewSettingsManager_C
// Size: 0x28 (Inherited: 0x28)
struct UFrontendItemViewSettingsManager_C : UFortFrontendItemViewSettingsManager {

	bool Is Hero or Previews on Hero(struct UFortItemDefinition* Item Definition, int32_t SubslotIndex); // Function FrontendItemViewSettingsManager.FrontendItemViewSettingsManager_C.Is Hero or Previews on Hero // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xda7c34
	struct FFortItemViewSettings GetItemViewSettings(enum class EFrontEndCamera Camera, enum class ESubGame GameMode, struct UFortItemDefinition* ItemDefinition, int32_t SubslotIndex); // Function FrontendItemViewSettingsManager.FrontendItemViewSettingsManager_C.GetItemViewSettings // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xda7c34
};

