// SolarisGeneratedEnum Entity_Geometry_DefaultMeshType.DefaultMeshType
enum class DefaultMeshType : uint8 {
	CUBE,
	Sphere,
	Cylinder,
	Cone,
	Plane,
};

