// BlueprintGeneratedClass GCNS_GM_OnDisplayChatEmoji.GCNS_GM_OnDisplayChatEmoji_C
// Size: 0x7c (Inherited: 0x70)
struct UGCNS_GM_OnDisplayChatEmoji_C : UFortGameplayCueNotify_Simple {
	struct FVector ParticleRelativeOffset; // 0x70(0x0c)

	void OnStartParticleSystemSpawned(struct UParticleSystemComponent* SpawnedParticleSysComponent, struct FGameplayCueParameters Parameters); // Function GCNS_GM_OnDisplayChatEmoji.GCNS_GM_OnDisplayChatEmoji_C.OnStartParticleSystemSpawned // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xda7c34
};

