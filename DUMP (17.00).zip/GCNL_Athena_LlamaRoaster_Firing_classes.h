// BlueprintGeneratedClass GCNL_Athena_LlamaRoaster_Firing.GCNL_Athena_LlamaRoaster_Firing_C
// Size: 0x7d0 (Inherited: 0x7d0)
struct AGCNL_Athena_LlamaRoaster_Firing_C : AFortGameplayCueNotify_Loop {
};

