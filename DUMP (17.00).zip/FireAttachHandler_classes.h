// BlueprintGeneratedClass FireAttachHandler.FireAttachHandler_C
// Size: 0xc0 (Inherited: 0xc0)
struct UFireAttachHandler_C : UFortCurieElementAttachHandlerFire {
};

