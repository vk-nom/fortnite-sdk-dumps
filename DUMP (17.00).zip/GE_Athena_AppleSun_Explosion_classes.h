// BlueprintGeneratedClass GE_Athena_AppleSun_Explosion.GE_Athena_AppleSun_Explosion_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_AppleSun_Explosion_C : UGameplayEffect {
};

