// SolarisGeneratedEnum Entity_Physics_PhysicsTraceType.PhysicsTraceType
enum class PhysicsTraceType : uint8 {
	Single,
	Multi,
	Test,
};

