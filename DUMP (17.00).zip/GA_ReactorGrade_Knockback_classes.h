// BlueprintGeneratedClass GA_ReactorGrade_Knockback.GA_ReactorGrade_Knockback_C
// Size: 0xd08 (Inherited: 0xd08)
struct UGA_ReactorGrade_Knockback_C : UGA_Athena_Knockback_Parent_C {
};

