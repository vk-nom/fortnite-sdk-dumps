// BlueprintGeneratedClass GE_Athena_Knockback_Status.GE_Athena_Knockback_Status_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_Knockback_Status_C : UGameplayEffect {
};

