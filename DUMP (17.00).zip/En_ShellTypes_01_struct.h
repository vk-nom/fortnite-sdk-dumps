// UserDefinedEnum En_ShellTypes_01.En_ShellTypes_01
enum class En_ShellTypes_01 : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	NewEnumerator4,
	En_ShellTypes_MAX,
};

