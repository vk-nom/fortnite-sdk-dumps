// BlueprintGeneratedClass FriendNotification.FriendNotification_C
// Size: 0x110 (Inherited: 0x108)
struct UFriendNotification_C : UFortUIFriendNotification {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x108(0x08)

	void JoinPartyInvite(); // Function FriendNotification.FriendNotification_C.JoinPartyInvite // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void ShowFriendInvites(); // Function FriendNotification.FriendNotification_C.ShowFriendInvites // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_FriendNotification(int32_t EntryPoint); // Function FriendNotification.FriendNotification_C.ExecuteUbergraph_FriendNotification // (Final|UbergraphFunction) // @ game+0xda7c34
};

