// BlueprintGeneratedClass GE_Athena_MedConsumable_Parent.GE_Athena_MedConsumable_Parent_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_MedConsumable_Parent_C : UGameplayEffect {
};

