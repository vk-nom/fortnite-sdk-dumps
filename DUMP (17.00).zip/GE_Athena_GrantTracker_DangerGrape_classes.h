// BlueprintGeneratedClass GE_Athena_GrantTracker_DangerGrape.GE_Athena_GrantTracker_DangerGrape_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_GrantTracker_DangerGrape_C : UGameplayEffect {
};

