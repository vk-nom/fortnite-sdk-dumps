// BlueprintGeneratedClass GA_Ranged_GenericProjectileExplosive.GA_Ranged_GenericProjectileExplosive_C
// Size: 0xab1 (Inherited: 0xab1)
struct UGA_Ranged_GenericProjectileExplosive_C : UGA_Ranged_GenericDamage_C {
};

