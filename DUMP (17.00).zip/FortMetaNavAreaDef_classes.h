// BlueprintGeneratedClass FortMetaNavAreaDef.FortMetaNavAreaDef_C
// Size: 0x58 (Inherited: 0x58)
struct UFortMetaNavAreaDef_C : UFortMetaNavArea {
};

