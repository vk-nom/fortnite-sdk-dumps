// BlueprintGeneratedClass FoleyLib_Hightower_Squash.FoleyLib_Hightower_Squash_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Hightower_Squash_C : UFoleyLib_Character_Base_C {
};

