// BlueprintGeneratedClass FoleyLib_Historian.FoleyLib_Historian_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Historian_C : UFoleyLib_Character_Base_C {
};

