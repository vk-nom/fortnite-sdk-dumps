// BlueprintGeneratedClass EventMode_Activator_Component.EventMode_Activator_Component_C
// Size: 0x210 (Inherited: 0x210)
struct UEventMode_Activator_Component_C : UFortGameFrameworkComponent_EventMode {
};

