// BlueprintGeneratedClass GCN_ValetMod_OffRoadTire_Apply.GCN_ValetMod_OffRoadTire_Apply_C
// Size: 0x458 (Inherited: 0x458)
struct AGCN_ValetMod_OffRoadTire_Apply_C : AFortGameplayCueNotify_BurstLatent {

	void OnBurst(struct AActor* MyTarget, struct FGameplayCueParameters Parameters, struct TArray<struct UParticleSystemComponent*> ParticleComponents, struct TArray<struct UAudioComponent*> AudioComponents, struct UMatineeCameraShake* BurstCameraShakeInstance, struct ADecalActor* BurstDecalInstance); // Function GCN_ValetMod_OffRoadTire_Apply.GCN_ValetMod_OffRoadTire_Apply_C.OnBurst // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xda7c34
};

