// BlueprintGeneratedClass FrontEndSettingsBP.FrontEndSettingsBP_C
// Size: 0x248 (Inherited: 0x240)
struct AFrontEndSettingsBP_C : AFrontEndSettings {
	struct USceneComponent* DefaultSceneRoot; // 0x240(0x08)
};

