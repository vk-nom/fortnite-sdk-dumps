// BlueprintGeneratedClass GA_NPC_Wildlife_Knockback_Player.GA_NPC_Wildlife_Knockback_Player_C
// Size: 0xb6c (Inherited: 0xb6c)
struct UGA_NPC_Wildlife_Knockback_Player_C : UGAB_GenericApplyKnockback_C {
};

