// BlueprintGeneratedClass GA_Athena_FloppingRabbit_HighTier.GA_Athena_FloppingRabbit_HighTier_C
// Size: 0xe30 (Inherited: 0xe30)
struct UGA_Athena_FloppingRabbit_HighTier_C : UGA_Athena_FloppingRabbit_C {
};

