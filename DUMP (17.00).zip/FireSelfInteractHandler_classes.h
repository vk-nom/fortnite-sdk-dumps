// BlueprintGeneratedClass FireSelfInteractHandler.FireSelfInteractHandler_C
// Size: 0x38 (Inherited: 0x38)
struct UFireSelfInteractHandler_C : UFortCurieElementInteractWithSameElementHandler {
};

