// BlueprintGeneratedClass FortNavArea_JumpDownSmashable2.FortNavArea_JumpDownSmashable2_C
// Size: 0x58 (Inherited: 0x58)
struct UFortNavArea_JumpDownSmashable2_C : UFortNavArea_SmashableJump {
};

