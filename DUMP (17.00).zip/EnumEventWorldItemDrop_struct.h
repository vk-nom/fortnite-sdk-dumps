// UserDefinedEnum EnumEventWorldItemDrop.EnumEventWorldItemDrop
enum class EnumEventWorldItemDrop : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	EnumEventWorldItemDrop_MAX,
};

