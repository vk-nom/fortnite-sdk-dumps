// UserDefinedEnum Enum_HeldObject_GenericWeights.Enum_HeldObject_GenericWeights
enum class Enum_HeldObject_GenericWeights : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	Enum_HeldObject_MAX,
};

