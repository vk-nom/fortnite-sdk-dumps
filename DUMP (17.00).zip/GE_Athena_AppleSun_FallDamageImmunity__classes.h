// BlueprintGeneratedClass GE_Athena_AppleSun_FallDamageImmunity_.GE_Athena_AppleSun_FallDamageImmunity__C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_AppleSun_FallDamageImmunity__C : UGameplayEffect {
};

