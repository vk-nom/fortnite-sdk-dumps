// BlueprintGeneratedClass GA_Slurpshroom_ShieldHealth.GA_Slurpshroom_ShieldHealth_C
// Size: 0xac8 (Inherited: 0xac8)
struct UGA_Slurpshroom_ShieldHealth_C : UGA_Coconut_ShieldHealth_C {
};

