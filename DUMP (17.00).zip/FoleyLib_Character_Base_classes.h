// BlueprintGeneratedClass FoleyLib_Character_Base.FoleyLib_Character_Base_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Character_Base_C : USoundLibrary {
};

