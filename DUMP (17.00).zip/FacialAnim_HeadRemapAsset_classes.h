// BlueprintGeneratedClass FacialAnim_HeadRemapAsset.FacialAnim_HeadRemapAsset_C
// Size: 0x30 (Inherited: 0x30)
struct UFacialAnim_HeadRemapAsset_C : UFacialLiveLinkRemapAsset {
};

