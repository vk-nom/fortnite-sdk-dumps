// BlueprintGeneratedClass GE_Athena_FallDmgImmune_FX.GE_Athena_FallDmgImmune_FX_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_FallDmgImmune_FX_C : UGameplayEffect {
};

