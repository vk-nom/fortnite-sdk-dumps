// BlueprintGeneratedClass GE_Athena_FloppingRabbit_Pull.GE_Athena_FloppingRabbit_Pull_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_FloppingRabbit_Pull_C : UGameplayEffect {
};

