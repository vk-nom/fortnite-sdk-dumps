// BlueprintGeneratedClass GA_Athena_Coconut.GA_Athena_Coconut_C
// Size: 0xc18 (Inherited: 0xc18)
struct UGA_Athena_Coconut_C : UGA_Athena_ForagedItemVersion_Consume_Parent_C {
};

