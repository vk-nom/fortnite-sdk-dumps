// UserDefinedEnum EBillboardshadowDirection.EBillboardshadowDirection
enum class EBillboardshadowDirection : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	NewEnumerator4,
	EBillboardshadowDirection_MAX,
};

