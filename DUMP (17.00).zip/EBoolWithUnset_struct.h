// UserDefinedEnum EBoolWithUnset.EBoolWithUnset
enum class EBoolWithUnset : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	EBoolWithUnset_MAX,
};

