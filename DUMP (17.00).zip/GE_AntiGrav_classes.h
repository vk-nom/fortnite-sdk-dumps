// BlueprintGeneratedClass GE_AntiGrav.GE_AntiGrav_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_AntiGrav_C : UGameplayEffect {
};

