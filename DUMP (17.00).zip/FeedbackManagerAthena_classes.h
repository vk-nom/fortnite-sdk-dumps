// BlueprintGeneratedClass FeedbackManagerAthena.FeedbackManagerAthena_C
// Size: 0x360 (Inherited: 0x358)
struct AFeedbackManagerAthena_C : AFortFeedbackManager {
	struct USceneComponent* DefaultSceneRoot; // 0x358(0x08)
};

