// BlueprintGeneratedClass DoorMetaObstacle.DoorMetaObstacle_C
// Size: 0xc8 (Inherited: 0xc8)
struct UDoorMetaObstacle_C : UNavAreaMeta_SwitchByAgent {
};

