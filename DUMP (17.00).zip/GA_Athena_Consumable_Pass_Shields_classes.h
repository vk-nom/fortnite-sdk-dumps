// BlueprintGeneratedClass GA_Athena_Consumable_Pass_Shields.GA_Athena_Consumable_Pass_Shields_C
// Size: 0xc0c (Inherited: 0xc0c)
struct UGA_Athena_Consumable_Pass_Shields_C : UGA_Athena_Consumable_Pass_Parent_C {
};

