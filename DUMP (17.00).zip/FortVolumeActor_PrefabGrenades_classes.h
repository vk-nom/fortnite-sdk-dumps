// BlueprintGeneratedClass FortVolumeActor_PrefabGrenades.FortVolumeActor_PrefabGrenades_C
// Size: 0x658 (Inherited: 0x650)
struct AFortVolumeActor_PrefabGrenades_C : AFortVolumeActor_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x650(0x08)

	void OnDeathPlayEffects_3(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function FortVolumeActor_PrefabGrenades.FortVolumeActor_PrefabGrenades_C.OnDeathPlayEffects_3 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_FortVolumeActor_PrefabGrenades(int32_t EntryPoint); // Function FortVolumeActor_PrefabGrenades.FortVolumeActor_PrefabGrenades_C.ExecuteUbergraph_FortVolumeActor_PrefabGrenades // (Final|UbergraphFunction|HasDefaults) // @ game+0xda7c34
};

