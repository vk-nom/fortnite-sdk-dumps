// SolarisGeneratedEnum Entity_Geometry_CollisionType.CollisionType
enum class CollisionType : uint8 {
	NoCollision,
	QueryOnly,
	SimulationOnly,
	QueryAndSimulation,
};

