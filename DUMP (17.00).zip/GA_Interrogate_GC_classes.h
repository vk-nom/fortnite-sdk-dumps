// BlueprintGeneratedClass GA_Interrogate_GC.GA_Interrogate_GC_C
// Size: 0xa80 (Inherited: 0xa70)
struct UGA_Interrogate_GC_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)
	struct FGameplayTag Cue; // 0xa78(0x08)

	void K2_ActivateAbility(); // Function GA_Interrogate_GC.GA_Interrogate_GC_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_Interrogate_GC(int32_t EntryPoint); // Function GA_Interrogate_GC.GA_Interrogate_GC_C.ExecuteUbergraph_GA_Interrogate_GC // (Final|UbergraphFunction|HasDefaults) // @ game+0xda7c34
};

