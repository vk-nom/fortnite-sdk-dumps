// BlueprintGeneratedClass GA_Ranged_GenericDamage_Suppressed_Athena.GA_Ranged_GenericDamage_Suppressed_Athena_C
// Size: 0xab1 (Inherited: 0xab1)
struct UGA_Ranged_GenericDamage_Suppressed_Athena_C : UGA_Ranged_GenericDamage_C {
};

