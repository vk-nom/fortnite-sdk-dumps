// BlueprintGeneratedClass GCN_UnstableBow_Outro.GCN_UnstableBow_Outro_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_UnstableBow_Outro_C : UFortGameplayCueNotify_Burst {
};

