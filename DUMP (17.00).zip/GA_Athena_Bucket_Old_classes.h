// BlueprintGeneratedClass GA_Athena_Bucket_Old.GA_Athena_Bucket_Old_C
// Size: 0xe04 (Inherited: 0xe04)
struct UGA_Athena_Bucket_Old_C : UGA_Athena_Consumable_Throw_Parent_C {
};

