// BlueprintGeneratedClass GCN_Athena_GrenadeLauncher_Bounce.GCN_Athena_GrenadeLauncher_Bounce_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_Athena_GrenadeLauncher_Bounce_C : UFortGameplayCueNotify_Burst {
};

