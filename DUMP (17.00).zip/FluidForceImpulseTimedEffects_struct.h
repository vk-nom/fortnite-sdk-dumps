// UserDefinedStruct FluidForceImpulseTimedEffects.FluidForceImpulseTimedEffects
// Size: 0x28 (Inherited: 0x00)
struct FFluidForceImpulseTimedEffects {
	bool EnableWaterDropsEffect_39_0A7932284406807D62695D8E0927BD70; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float EffectRadius_30_C9A94C02422D8BF40DF6B1BB2A0D8CBC; // 0x04(0x04)
	float Strength_29_2CAA30794D1EFF60AE1C3491D011CECF; // 0x08(0x04)
	float WaterDropsperSquareMeter_27_C31B527C4C367A5CA5E1DF8E49E76234; // 0x0c(0x04)
	float StartTimeOffset_33_5A792CE8489A59E5D9B24F9E4DCFE94A; // 0x10(0x04)
	float Lifetime_35_C2749C1449C41D4F236BCBAF6ED34113; // 0x14(0x04)
	float StrengthoverLifePower_37_4FA6941A4AD024828AFEB782783DD01C; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct UMaterialInterface* MaterialOverride_42_FB856A244A1713590BB76EAA7CC7A0DF; // 0x20(0x08)
};

