// Class FacialAnimSystem.FacialLiveLinkRemapAsset
// Size: 0x30 (Inherited: 0x28)
struct UFacialLiveLinkRemapAsset : ULiveLinkRetargetAsset {
	bool bExtractBoneTransform; // 0x28(0x01)
	bool bExtractCurve; // 0x29(0x01)
	char pad_2A[0x6]; // 0x2a(0x06)
};

