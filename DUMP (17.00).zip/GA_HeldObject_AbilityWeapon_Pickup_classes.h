// BlueprintGeneratedClass GA_HeldObject_AbilityWeapon_Pickup.GA_HeldObject_AbilityWeapon_Pickup_C
// Size: 0xa78 (Inherited: 0xa70)
struct UGA_HeldObject_AbilityWeapon_Pickup_C : UFortGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa70(0x08)

	void OnCancelled_064121774728AAB46B8294B952EF27BA(); // Function GA_HeldObject_AbilityWeapon_Pickup.GA_HeldObject_AbilityWeapon_Pickup_C.OnCancelled_064121774728AAB46B8294B952EF27BA // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnInterrupted_064121774728AAB46B8294B952EF27BA(); // Function GA_HeldObject_AbilityWeapon_Pickup.GA_HeldObject_AbilityWeapon_Pickup_C.OnInterrupted_064121774728AAB46B8294B952EF27BA // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnBlendOut_064121774728AAB46B8294B952EF27BA(); // Function GA_HeldObject_AbilityWeapon_Pickup.GA_HeldObject_AbilityWeapon_Pickup_C.OnBlendOut_064121774728AAB46B8294B952EF27BA // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void OnCompleted_064121774728AAB46B8294B952EF27BA(); // Function GA_HeldObject_AbilityWeapon_Pickup.GA_HeldObject_AbilityWeapon_Pickup_C.OnCompleted_064121774728AAB46B8294B952EF27BA // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void K2_ActivateAbility(); // Function GA_HeldObject_AbilityWeapon_Pickup.GA_HeldObject_AbilityWeapon_Pickup_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_HeldObject_AbilityWeapon_Pickup(int32_t EntryPoint); // Function GA_HeldObject_AbilityWeapon_Pickup.GA_HeldObject_AbilityWeapon_Pickup_C.ExecuteUbergraph_GA_HeldObject_AbilityWeapon_Pickup // (Final|UbergraphFunction) // @ game+0xda7c34
};

