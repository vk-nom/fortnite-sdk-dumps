// UserDefinedEnum ECreativeTeamColor.ECreativeTeamColor
enum class ECreativeTeamColor : uint8 {
	NewEnumerator0,
	NewEnumerator1,
	NewEnumerator2,
	NewEnumerator3,
	NewEnumerator4,
	NewEnumerator5,
	NewEnumerator6,
	NewEnumerator7,
	NewEnumerator8,
	NewEnumerator9,
	NewEnumerator10,
	NewEnumerator11,
	NewEnumerator12,
	NewEnumerator13,
	NewEnumerator14,
	NewEnumerator15,
	NewEnumerator17,
	NewEnumerator18,
	ECreativeTeamColor_MAX,
};

