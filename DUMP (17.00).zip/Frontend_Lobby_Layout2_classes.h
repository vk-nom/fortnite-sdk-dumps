// BlueprintGeneratedClass Frontend_Lobby_Layout2.Frontend_Lobby_Layout2_C
// Size: 0x238 (Inherited: 0x238)
struct AFrontend_Lobby_Layout2_C : AFortLevelScriptActor {
};

