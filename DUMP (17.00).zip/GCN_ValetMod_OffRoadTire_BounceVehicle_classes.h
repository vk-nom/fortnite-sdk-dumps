// BlueprintGeneratedClass GCN_ValetMod_OffRoadTire_BounceVehicle.GCN_ValetMod_OffRoadTire_BounceVehicle_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_ValetMod_OffRoadTire_BounceVehicle_C : UFortGameplayCueNotify_Burst {

	void OnBurstNiagara(struct AActor* MyTarget, struct FGameplayCueParameters Parameters, struct TArray<struct UNiagaraComponent*> ParticleComponents, struct TArray<struct UAudioComponent*> AudioComponents, struct UMatineeCameraShake* BurstCameraShakeInstance, struct ADecalActor* BurstDecalInstance); // Function GCN_ValetMod_OffRoadTire_BounceVehicle.GCN_ValetMod_OffRoadTire_BounceVehicle_C.OnBurstNiagara // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xda7c34
};

