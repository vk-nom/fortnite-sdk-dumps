// BlueprintGeneratedClass GA_Throw_Petrol_Pump_AsHeldObjectBGA.GA_Throw_Petrol_Pump_AsHeldObjectBGA_C
// Size: 0xc10 (Inherited: 0xc04)
struct UGA_Throw_Petrol_Pump_AsHeldObjectBGA_C : UGA_Athena_Consumable_ThrowWithTrajectoryAsHeldObjectBGA_Parent_C {
	char pad_C04[0x4]; // 0xc04(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc08(0x08)

	void UpdateDummyProjectileBGA(); // Function GA_Throw_Petrol_Pump_AsHeldObjectBGA.GA_Throw_Petrol_Pump_AsHeldObjectBGA_C.UpdateDummyProjectileBGA // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void UpdateSpawnedBGA(ServerOnly)(); // Function GA_Throw_Petrol_Pump_AsHeldObjectBGA.GA_Throw_Petrol_Pump_AsHeldObjectBGA_C.UpdateSpawnedBGA(ServerOnly) // (BlueprintCallable|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_Throw_Petrol_Pump_AsHeldObjectBGA(int32_t EntryPoint); // Function GA_Throw_Petrol_Pump_AsHeldObjectBGA.GA_Throw_Petrol_Pump_AsHeldObjectBGA_C.ExecuteUbergraph_GA_Throw_Petrol_Pump_AsHeldObjectBGA // (Final|UbergraphFunction) // @ game+0xda7c34
};

