// BlueprintGeneratedClass FoleyLib_Embers.FoleyLib_Embers_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Embers_C : UFoleyLib_Character_Base_C {
};

