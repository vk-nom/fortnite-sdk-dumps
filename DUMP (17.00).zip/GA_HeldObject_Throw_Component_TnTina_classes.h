// BlueprintGeneratedClass GA_HeldObject_Throw_Component_TnTina.GA_HeldObject_Throw_Component_TnTina_C
// Size: 0xc58 (Inherited: 0xc50)
struct UGA_HeldObject_Throw_Component_TnTina_C : UGA_HeldObject_Throw_Component_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc50(0x08)

	void K2_ActivateAbility(); // Function GA_HeldObject_Throw_Component_TnTina.GA_HeldObject_Throw_Component_TnTina_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0xda7c34
	void ExecuteUbergraph_GA_HeldObject_Throw_Component_TnTina(int32_t EntryPoint); // Function GA_HeldObject_Throw_Component_TnTina.GA_HeldObject_Throw_Component_TnTina_C.ExecuteUbergraph_GA_HeldObject_Throw_Component_TnTina // (Final|UbergraphFunction) // @ game+0xda7c34
};

