// AnimBlueprintGeneratedClass F_MED_HIS_Ramirez_Head_01_AnimBP_Child.F_MED_HIS_Ramirez_Head_01_AnimBP_Child_C
// Size: 0x1972 (Inherited: 0x1972)
struct UF_MED_HIS_Ramirez_Head_01_AnimBP_Child_C : UFortnite_Base_Head_Export_Skeleton_AnimBP_C {
};

