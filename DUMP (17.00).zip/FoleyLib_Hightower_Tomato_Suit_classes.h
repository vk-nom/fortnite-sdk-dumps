// BlueprintGeneratedClass FoleyLib_Hightower_Tomato_Suit.FoleyLib_Hightower_Tomato_Suit_C
// Size: 0xb0 (Inherited: 0xb0)
struct UFoleyLib_Hightower_Tomato_Suit_C : UFoleyLib_Character_Base_C {
};

