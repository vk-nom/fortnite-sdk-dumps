// BlueprintGeneratedClass GE_Athena_Cabbage.GE_Athena_Cabbage_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_Cabbage_C : UGameplayEffect {
};

