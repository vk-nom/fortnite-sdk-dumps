// BlueprintGeneratedClass GA_Athena_Consumable_ThrowWithTrajectory_Whiff.GA_Athena_Consumable_ThrowWithTrajectory_Whiff_C
// Size: 0xc0c (Inherited: 0xc0c)
struct UGA_Athena_Consumable_ThrowWithTrajectory_Whiff_C : UGA_Athena_Consumable_Pass_Parent_C {
};

