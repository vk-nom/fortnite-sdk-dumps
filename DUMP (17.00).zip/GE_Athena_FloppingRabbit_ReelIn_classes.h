// BlueprintGeneratedClass GE_Athena_FloppingRabbit_ReelIn.GE_Athena_FloppingRabbit_ReelIn_C
// Size: 0x800 (Inherited: 0x800)
struct UGE_Athena_FloppingRabbit_ReelIn_C : UGameplayEffect {
};

