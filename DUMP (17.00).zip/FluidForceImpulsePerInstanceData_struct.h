// UserDefinedStruct FluidForceImpulsePerInstanceData.FluidForceImpulsePerInstanceData
// Size: 0x59 (Inherited: 0x00)
struct FFluidForceImpulsePerInstanceData {
	struct FFluidForceImpulse ImpulseSettings_41_C9A94C02422D8BF40DF6B1BB2A0D8CBC; // 0x00(0x50)
	float ElapsedTime_44_12C387C1450456E47FC74BBD11EEAE4F; // 0x50(0x04)
	float StartOffset_48_78EF0E3F4B05F70C5679F9B9F41D590F; // 0x54(0x04)
	bool IsSplashEffect_54_4A5B178940D26E71D6FCDF84584A5284; // 0x58(0x01)
};

