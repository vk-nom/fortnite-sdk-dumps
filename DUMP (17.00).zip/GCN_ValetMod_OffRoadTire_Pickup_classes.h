// BlueprintGeneratedClass GCN_ValetMod_OffRoadTire_Pickup.GCN_ValetMod_OffRoadTire_PickUp_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UGCN_ValetMod_OffRoadTire_PickUp_C : UFortGameplayCueNotify_Burst {
};

